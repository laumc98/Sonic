SELECT 
  id as 'Company_id',
  name as 'Company' 
  
FROM organizations;
